#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Nov  7 13:42:15 2023

@author: sheshta
"""
import csv
import itertools
import random
import math
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from geopy.distance import geodesic

# Define city data in a pandas DataFrame
cities = {
    "City": [
        "City 0",
        "City 1",
        "City 2",
        "City 3",
        "City 4",
        "City 5",
        "City 6",
        "City 7",
        "City 8",
        "City 9",
    ],
    "x": [
        52.5200,
        53.5511,
        48.1351,
        50.9375,
        50.1109,
        38.7223,
        50.8503,
        51.5074,
        48.8566,
        41.3851,
    ],
    "y": [
        13.4050,
        9.9937,
        11.5820,
        6.9603,
        8.6821,
        -9.1393,
        4.3517,
        -0.1278,
        2.3522,
        2.1734,
    ],
}
df = pd.DataFrame(cities)

# Calculate distances between cities using Haversine formula
def distance_between(city1, city2):
    x1, y1 = city1["x"], city1["y"]
    x2, y2 = city2["x"], city2["y"]
    return geodesic((x1, y1), (x2, y2)).kilometers

# Generate the distance matrix
def get_distance_matrix(cities):
    num_cities = len(cities)
    distances = np.zeros((num_cities, num_cities))
    for i in range(num_cities):
        for j in range(i + 1, num_cities):
            dist = distance_between(cities.iloc[i], cities.iloc[j])
            distances[i][j] = int(dist)
            distances[j][i] = int(dist)
    return distances

distances = get_distance_matrix(df)

# Brute Force TSP
# Brute Force TSP with return to starting city
def solve_tsp_brute_force(distances):
    num_cities = len(distances)
    all_cities = list(range(num_cities))
    min_distance = float("inf")
    best_route = None

    for route in itertools.permutations(all_cities):
        distance = 0
        for i in range(num_cities - 1):
            distance += distances[route[i]][route[i + 1]]
        distance += distances[route[-1]][route[0]]  # Return to the starting city

        if distance < min_distance:
            min_distance = distance
            best_route = route

    # Ensure the last city in the route is the same as the first city
    best_route = tuple(list(best_route) + [best_route[0]])
    return best_route, min_distance

brute_force_tour, brute_force_distance = solve_tsp_brute_force(distances)


# Nearest Neighbor TSP
def solve_tsp_nearest(distances):
    num_cities = len(distances)
    visited = [False] * num_cities
    tour = []
    total_distance = 0

    current_city = 0
    tour.append(current_city)
    visited[current_city] = True

    while len(tour) < num_cities:
        nearest_city = None
        nearest_distance = math.inf

        for city in range(num_cities):
            if not visited[city]:
                distance = distances[current_city][city]
                if distance < nearest_distance:
                    nearest_city = city
                    nearest_distance = distance

        current_city = nearest_city
        tour.append(current_city)
        visited[current_city] = True
        total_distance += nearest_distance

    tour.append(0)
    total_distance += distances[current_city][0]

    return tour, total_distance

nearest_neighbor_tour, nearest_neighbor_distance = solve_tsp_nearest(distances)

# ACO TSP
def aco_tsp(distances, num_ants=50, pheromone_evaporation=0.1, pheromone_deposit=1.0, alpha=1.0, beta=2.0, q0=0.7, num_iterations=100):
    num_cities = len(distances)
    pheromone_levels = np.ones((num_cities, num_cities)) * 0.1
    best_tour = None
    best_tour_length = float('inf')

    for iteration in range(num_iterations):
        ant_tours = []

        for ant in range(num_ants):
            current_city = 0
            tour = [current_city]
            tour_length = 0

            while len(tour) < num_cities:
                unvisited_cities = [city for city in range(num_cities) if city not in tour]
                probabilities = []

                for city in unvisited_cities:
                    pheromone = pheromone_levels[current_city][city]
                    distance = distances[current_city][city]
                    probability = (pheromone ** alpha) * ((1 / distance) ** beta)
                    probabilities.append((city, probability))

                if random.random() < q0:
                    next_city = max(probabilities, key=lambda x: x[1])[0]
                else:
                    total_prob = sum(prob for city, prob in probabilities)
                    selected = random.random() * total_prob
                    cumulative_prob = 0

                    for city, prob in probabilities:
                        cumulative_prob += prob
                        if cumulative_prob >= selected:
                            next_city = city
                            break

                tour.append(next_city)
                current_city = next_city
                tour_length += distances[tour[-2]][tour[-1]]

            tour_length += distances[tour[-1]][tour[0]]
            tour.append(tour[0])

            ant_tours.append((tour, tour_length))

        for i in range(num_cities):
            for j in range(i + 1, num_cities):
                delta_pheromone = 0
                for ant_tour, ant_length in ant_tours:
                    if (i, j) in zip(ant_tour, ant_tour[1:]):
                        delta_pheromone += pheromone_deposit / ant_length
                pheromone_levels[i][j] = (1 - pheromone_evaporation) * pheromone_levels[i][j] + delta_pheromone

        for ant_tour, ant_length in ant_tours:
            if ant_length < best_tour_length:
                best_tour_length = ant_length
                best_tour = ant_tour

    return best_tour, best_tour_length

aco_tour, aco_distance = aco_tsp(distances)

# Extract the coordinates of cities in the tour
aco_tour_cities = [df.iloc[i] for i in aco_tour]

# Extract the coordinates of cities in the nearest neighbor tour
nn_tour_cities = [df.iloc[i] for i in nearest_neighbor_tour]

# Extract the coordinates of cities in the brute force tour
bf_tour_cities = [df.iloc[i] for i in brute_force_tour]

# Plot the cities on a scatter plot
plt.figure(figsize=(8, 6))
plt.scatter(df["y"], df["x"])
for i, city in df.iterrows():
    plt.annotate(city["City"], (city["y"], city["x"]))

# Plot the Brute Force tour
bf_lats = [city["x"] for city in bf_tour_cities]
bf_lons = [city["y"] for city in bf_tour_cities]

plt.figure(figsize=(8, 6))
plt.scatter(df["y"], df["x"])
for i, city in df.iterrows():
    plt.annotate(city["City"], (city["y"], city["x"]))
plt.plot(bf_lons, bf_lats, 'b-')
plt.title("Brute Force Tour")
plt.xlabel("Longitude")
plt.ylabel("Latitude")

# Plot the Nearest Neighbor tour
nn_lats = [city["x"] for city in nn_tour_cities]
nn_lons = [city["y"] for city in nn_tour_cities]

plt.figure(figsize=(8, 6))
plt.scatter(df["y"], df["x"])
for i, city in df.iterrows():
    plt.annotate(city["City"], (city["y"], city["x"]))
plt.plot(nn_lons, nn_lats, 'r-')
plt.title("Nearest Neighbor Tour")
plt.xlabel("Longitude")
plt.ylabel("Latitude")

# Plot the ACO tour
aco_lats = [city["x"] for city in aco_tour_cities]
aco_lons = [city["y"] for city in aco_tour_cities]

plt.figure(figsize=(8, 6))
plt.scatter(df["y"], df["x"])
for i, city in df.iterrows():
    plt.annotate(city["City"], (city["y"], city["x"]))
plt.plot(aco_lons, aco_lats, 'g-')
plt.title("ACO Tour")
plt.xlabel("Longitude")
plt.ylabel("Latitude")

plt.show()

# Print results
print("Brute Force Tour:", brute_force_tour)
print("Brute Force Tour Length:", brute_force_distance)
print("Nearest Neighbor Tour:", nearest_neighbor_tour)
print("Nearest Neighbor Tour Length:", nearest_neighbor_distance)
print("ACO Tour:", aco_tour)
print("ACO Tour Length:", aco_distance)