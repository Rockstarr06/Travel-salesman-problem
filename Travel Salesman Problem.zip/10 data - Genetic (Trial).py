#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Nov 13 23:47:22 2023

@author: Pravesh
"""


import random
from math import radians, sin, cos, sqrt, atan2
import matplotlib.pyplot as plt
from math import radians, sin, cos, sqrt, atan2 

def haversine(coord1, coord2):
    # Haversine formula to calculate the distance between two points on the Earth
    R = 6371  # Radius of the Earth in kilometers

    lat1, lon1 = radians(coord1[1]), radians(coord1[2])
    lat2, lon2 = radians(coord2[1]), radians(coord2[2])

    dlat = lat2 - lat1
    dlon = lon2 - lon1

    a = sin(dlat / 2)**2 + cos(lat1) * cos(lat2) * sin(dlon / 2)**2
    c = 2 * atan2(sqrt(a), sqrt(1 - a))

    distance = R * c
    return distance

def total_distance(tour, city_coords):
    # Calculate the total distance of a tour
    total = 0
    for i in range(len(tour) - 1):
        total += haversine(city_coords[tour[i]], city_coords[tour[i + 1]])
    total += haversine(city_coords[tour[-1]], city_coords[tour[0]])  # Return to the starting city
    return total

def generate_initial_population(num_individuals):
    # Generate an initial population of random tours
    population = []
    for _ in range(num_individuals):
        tour = list(range(len(cities)))
        random.shuffle(tour)
        population.append(tour)
    return population

def crossover(parent1, parent2):
    # Order crossover (OX) - a common crossover technique for TSP
    start, end = sorted(random.sample(range(len(parent1)), 2))

    child = [-1] * len(parent1)
    child[start:end] = parent1[start:end]

    remaining_values = [value for value in parent2 if value not in child]

    index = 0
    for i in range(len(parent1)):
        if child[i] == -1:
            child[i] = remaining_values[index]
            index += 1

    return child

def mutate(individual, mutation_rate):
    # Swap mutation - randomly swap two cities in the tour
    if random.random() < mutation_rate:
        idx1, idx2 = random.sample(range(len(individual)), 2)
        individual[idx1], individual[idx2] = individual[idx2], individual[idx1]

def genetic_algorithm(cities, num_generations, population_size, crossover_rate, mutation_rate):
    city_coords = dict(enumerate(cities))

    population = generate_initial_population(population_size)

    for generation in range(num_generations):
        # Evaluate the fitness of each individual in the population
        fitness = [1 / total_distance(individual, city_coords) for individual in population]

        # Select parents based on fitness
        parents = random.choices(population, weights=fitness, k=population_size)

        # Perform crossover to create new individuals
        new_population = []
        for i in range(0, population_size, 2):
            parent1, parent2 = parents[i], parents[i + 1]
            child1 = crossover(parent1, parent2)
            child2 = crossover(parent2, parent1)
            new_population.extend([child1, child2])

        # Apply mutation to the new population
        for individual in new_population:
            mutate(individual, mutation_rate)

        population = new_population

    # Select the best individual from the final population
    best_individual = max(population, key=lambda x: 1 / total_distance(x, city_coords))

    # Return the best tour and its total distance
    return best_individual, total_distance(best_individual, city_coords)

# Set parameters
num_generations = 500
population_size = 100
crossover_rate = 0.8
mutation_rate = 0.2


# Define the list of cities with their coordinates
cities = [
    ('London', 52.52, 13.405),
    ('Wellington', 53.5511, 9.9937),
    ('Nebraska', 48.1351, 11.582),
    ('Kolkata', 50.9375, 6.9603),
    ('Bombay', 50.1109, 8.6821),
    ('Delhi', 38.7223, -9.1393),
    ('Las Vegas', 50.8503, 4.3517),
    ('California', 51.5074, -0.1278),
    ('Dubai', 48.8566, 2.3522),
    ('Chennai', 41.3851, 2.1734),
] 

# Run the genetic algorithm
best_tour, best_distance = genetic_algorithm(cities, num_generations, population_size, crossover_rate, mutation_rate)

print("Best tour:", best_tour)
print("Total distance:", best_distance, "km")  





# Run the genetic algorithm
best_tour, best_distance = genetic_algorithm(cities, num_generations, population_size, crossover_rate, mutation_rate)

print("Best tour:", best_tour)
print("Total distance:", best_distance, "km")

# Plot the best tour
best_tour_coordinates = [cities[i][1:3] for i in best_tour]
best_tour_coordinates.append(best_tour_coordinates[0])  # Connect back to the starting city
lats, lons = zip(*best_tour_coordinates)

plt.figure(figsize=(10, 6))
plt.plot(lons, lats, marker='o', linestyle='-', color='b')
plt.title('Genetic Algo Tour')
plt.xlabel('Longitude')
plt.ylabel('Latitude')
plt.grid(True)
plt.show() 