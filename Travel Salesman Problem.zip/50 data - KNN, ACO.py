#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Nov  7 15:27:39 2023

@author: sheshta
"""

import csv
import random
import math
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import folium
from geopy.distance import geodesic

# Read the data of the CSV file into a dict
def read_csv_into_dict(csv_file_path):
    cities = {}
    with open(csv_file_path, "r") as file:
        csv_reader = csv.reader(file)
        for row in csv_reader:
            key = row[0]
            value1 = row[1]
            value2 = row[2]
            cities[key] = (value1, value2)
    return cities

# Define a path to the CSV file
csv_file_path = "addresses.csv"

# Call the function and store the returned data
csv_data_dict = read_csv_into_dict(csv_file_path)

# Define city data in a pandas DataFrame
cities = {
    "City": list(csv_data_dict.keys()),
    "x": [float(coords[0]) for coords in csv_data_dict.values()],
    "y": [float(coords[1]) for coords in csv_data_dict.values()],
}
df = pd.DataFrame(cities)

# Calculate distances between cities using Haversine formula
def distance_between(city1, city2):
    x1, y1 = city1["x"], city1["y"]
    x2, y2 = city2["x"], city2["y"]
    return geodesic((x1, y1), (x2, y2)).kilometers

# Generate the distance matrix
def get_distance_matrix(cities):
    num_cities = len(cities)
    distances = np.zeros((num_cities, num_cities))
    for i in range(num_cities):
        for j in range(i + 1, num_cities):
            dist = distance_between(cities.iloc[i], cities.iloc[j])
            distances[i][j] = int(dist)
            distances[j][i] = int(dist)
    return distances

distances = get_distance_matrix(df)

# Nearest Neighbor TSP
def solve_tsp_nearest(distances):
    num_cities = len(distances)
    visited = [False] * num_cities
    tour = []
    total_distance = 0
    
    current_city = 0
    tour.append(current_city)
    visited[current_city] = True
    
    while len(tour) < num_cities:
        nearest_city = None
        nearest_distance = math.inf

        for city in range(num_cities):
            if not visited[city]:
                distance = distances[current_city][city]
                if distance < nearest_distance:
                    nearest_city = city
                    nearest_distance = distance

        current_city = nearest_city
        tour.append(current_city)
        visited[current_city] = True
        total_distance += nearest_distance

    tour.append(0)
    total_distance += distances[current_city][0]

    return tour, total_distance

nearest_neighbor_tour, nearest_neighbor_distance = solve_tsp_nearest(distances)

# ACO TSP
def aco_tsp(distances, num_ants=50, pheromone_evaporation=0.1, pheromone_deposit=1.0, alpha=1.0, beta=2.0, q0=0.7, num_iterations=100):
    num_cities = len(distances)
    pheromone_levels = np.ones((num_cities, num_cities)) * 0.1
    best_tour = None
    best_tour_length = float('inf')
    
    for iteration in range(num_iterations):
        ant_tours = []

        for ant in range(num_ants):
            current_city = 0
            tour = [current_city]
            tour_length = 0

            while len(tour) < num_cities:
                unvisited_cities = [city for city in range(num_cities) if city not in tour]
                probabilities = []

                for city in unvisited_cities:
                    pheromone = pheromone_levels[current_city][city]
                    distance = distances[current_city][city]
                    probability = (pheromone ** alpha) * ((1 / distance) ** beta)
                    probabilities.append((city, probability))

                if random.random() < q0:
                    next_city = max(probabilities, key=lambda x: x[1])[0]
                else:
                    total_prob = sum(prob for city, prob in probabilities)
                    selected = random.random() * total_prob
                    cumulative_prob = 0

                    for city, prob in probabilities:
                        cumulative_prob += prob
                        if cumulative_prob >= selected:
                            next_city = city
                            break

                tour.append(next_city)
                current_city = next_city
                tour_length += distances[tour[-2]][tour[-1]]

            tour_length += distances[tour[-1]][tour[0]]
            tour.append(tour[0])

            ant_tours.append((tour, tour_length))

        for i in range(num_cities):
            for j in range(i + 1, num_cities):
                delta_pheromone = 0
                for ant_tour, ant_length in ant_tours:
                    if (i, j) in zip(ant_tour, ant_tour[1:]):
                        delta_pheromone += pheromone_deposit / ant_length
                pheromone_levels[i][j] = (1 - pheromone_evaporation) * pheromone_levels[i][j] + delta_pheromone

        for ant_tour, ant_length in ant_tours:
            if ant_length < best_tour_length:
                best_tour_length = ant_length
                best_tour = ant_tour

    return best_tour, best_tour_length

aco_tour, aco_distance = aco_tsp(distances)

# Create a figure and axis for the Nearest Neighbor plot
fig1, ax1 = plt.subplots()
nn_tour_coords = [df.iloc[i][["x", "y"]].to_numpy() for i in nearest_neighbor_tour]
nn_tour_coords.append(df.iloc[nearest_neighbor_tour[0]][["x", "y"]].to_numpy())
nn_tour_x, nn_tour_y = zip(*nn_tour_coords)
ax1.plot(nn_tour_x, nn_tour_y, linestyle='-', marker='o', color='red')
ax1.set_title("Nearest Neighbor Tour")
ax1.axis('off')

# Create a Folium map for Nearest Neighbor Tour
m_nn = folium.Map(location=[df.iloc[0]['x'], df.iloc[0]['y']], zoom_start=6)

# Add markers for cities
for index, row in df.iterrows():
    x, y = row["x"], row["y"]
    folium.Marker([x, y], tooltip=row["City"]).add_to(m_nn)

# Create a list of coordinates for Nearest Neighbor Tour
nn_tour_coords = [(df.iloc[i]["x"], df.iloc[i]["y"]) for i in nearest_neighbor_tour]

# Create a line to connect cities in the Nearest Neighbor Tour
folium.PolyLine(locations=nn_tour_coords + [nn_tour_coords[0]], color="red").add_to(m_nn)

# Save the Nearest Neighbor map to an HTML file
m_nn.save("nearest_neighbor_tour.html")

# Create a figure and axis for the ACO plot
fig2, ax2 = plt.subplots()
aco_tour_coords = [df.iloc[i][["x", "y"]].to_numpy() for i in aco_tour]
aco_tour_coords.append(df.iloc[aco_tour[0]][["x", "y"]].to_numpy())
aco_tour_x, aco_tour_y = zip(*aco_tour_coords)
ax2.plot(aco_tour_x, aco_tour_y, linestyle='-', marker='o', color='green')
ax2.set_title("ACO Tour")
ax2.axis('off')

# Create a Folium map for ACO Tour
m_aco = folium.Map(location=[df.iloc[0]['x'], df.iloc[0]['y']], zoom_start=6)

# Add markers for cities
for index, row in df.iterrows():
    x, y = row["x"], row["y"]
    folium.Marker([x, y], tooltip=row["City"]).add_to(m_aco)

# Create a list of coordinates for ACO Tour
aco_tour_coords = [(df.iloc[i]["x"], df.iloc[i]["y"]) for i in aco_tour]

# Create a line to connect cities in the ACO Tour
folium.PolyLine(locations=aco_tour_coords + [aco_tour_coords[0]], color="green").add_to(m_aco)

# Save the ACO map to an HTML file
m_aco.save("aco_tour.html")

# Display the plots
plt.show()

# Print results
print("Nearest Neighbor Tour Length:", nearest_neighbor_distance)
print("ACO Tour Length:", aco_distance)
